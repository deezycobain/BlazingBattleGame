Blazing Battle - Treasury Collection I: Legends of the Leaf
PACK 01 - APPROVED CARD ART + BANNER

Approved units:
TC-001-MDR Madara Uchiha
TC-002-HSR Hashirama Senju
TC-003-TSN Tsunade
TC-004-MNT Minato Namikaze

Art direction:
American-currency-inspired engraved linework, pale money green / ivory,
minimal selective character accent color, no Japanese text, no star row.

These PNGs are full-quality masters. Keep originals intact and create runtime
resizes/crops from copies only.
