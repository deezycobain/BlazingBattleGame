Blazing Battle - Treasury Collection Summon FX
PACK 02 - SUMMON ANIMATION ASSETS

Files:
treasury_seal_charge_atlas.png
  High-resolution Treasury seal charge/spin sequence.

treasury_blank_card_flip_atlas.png
  Blank card turning/reveal sequence. Character artwork should be injected at runtime,
  not baked into this animation.

treasury_reveal_fx_experimental_atlas.png
  Larger experimental reveal/VFX atlas. This version intentionally contains more frames;
  test in runtime first and prune frames if the animation feels over-animated.

treasury_blank_final_reveal_atlas.png
  Blank final reveal sequence. Use as the reusable reveal shell and composite the selected
  unit card/art dynamically.

Production rule:
Do not bake Madara, Hashirama, Tsunade, or Minato directly into shared flip/reveal frames.
Keep the summon shell reusable for any Treasury Collection unit.
