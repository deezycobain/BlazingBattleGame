# Blazing Battle – SubZero Test Assets

Included in this zip:
- idle
- run
- attack (basic attack)
- recoil

Runtime standard:
- 12 frames per animation
- 512x768 transparent PNG per frame
- 3072x1536 atlas per animation (6x2)
- right-facing

Contents path:
assets/characters/subzero/sprites/runtime/
