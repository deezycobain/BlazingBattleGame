# Blazing Battle Shared VFX Atlas

Canonical files:
- `mist_slash_shared_vfx.png`
- `mist_slash_shared_vfx.atlas.json`

## Runtime lookup

Use a stable effect ID, for example:

`shared.mist:mist_crescent_04`

The atlas JSON resolves that ID to an exact source rectangle in the PNG.

## Coordinate rule

- origin: top-left
- x increases right
- y increases down
- rectangle fields: x, y, width, height in pixels
- pivot fields are normalized 0..1 inside the extracted region

## Organization rule

Reusable VFX belong in the shared VFX library, not in the first unit that uses them.
Unit data should reference named atlas regions/sequences.
