# Ember Scout Common Asset Package

This package establishes the clean asset ownership rule for new Blazing Battle units.

## Character-owned
`assets/characters/ember-scout/`
- source sprite sheets
- runtime idle body frames
- runtime basic-attack body frames
- common card art

## Shared/reusable
`assets/effects/attacks/shared/fire-slash/`
- slash arcs
- trailing fire strokes
- impact bursts
- ember particles
- original VFX source sheet

Do not copy these shared VFX back into Ember Scout's character folder.
Future units should reference the shared assets when appropriate.

Full sprite sheets are retained as source/reference. Runtime body animations are exported as individual frame PNGs.
