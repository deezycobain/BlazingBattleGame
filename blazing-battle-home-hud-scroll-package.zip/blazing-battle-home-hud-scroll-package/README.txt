Blazing Battle HUD Scroll Assets

Included runtime-ready assets:
- assets/ui/home/hud/player-profile-scroll.png
- assets/ui/home/hud/embers-currency-scroll.png
- assets/ui/home/hud/gold-currency-scroll.png

Theme:
Persona-inspired / ninja scroll / red-black-white parchment.
