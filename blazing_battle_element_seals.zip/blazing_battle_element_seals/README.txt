Blazing Battle Element Seals

Files:
01_fire_seal.png
02_ice_seal.png
03_lightning_seal.png
04_wind_seal.png
05_earth_seal.png
06_shadow_seal.png
