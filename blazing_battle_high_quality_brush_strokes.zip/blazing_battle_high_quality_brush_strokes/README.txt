Blazing Battle - High Quality Summon Reveal Brush Strokes

01_horizontal_sweep.png
02_diagonal_slash.png
03_crescent_sweep.png
04_enso_ring.png
05_energy_burst.png
06_flowing_sweep.png

All artwork files are PNGs with alpha transparency.
