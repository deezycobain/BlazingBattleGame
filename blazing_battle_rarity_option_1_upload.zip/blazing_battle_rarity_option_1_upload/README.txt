Blazing Battle - Rarity Emblems Option 1

Target path:
assets/ui/summon/rarity/rarity_emblems_option_1.png
