Blazing Battle - Summon Reveal Card Assets

Intended repository paths:
  assets/ui/summon/reveal/summon_reveal_card_back.png
  assets/ui/summon/reveal/summon_reveal_card_front_frame.png

The PNGs are game-ready with transparent outer backgrounds. The front frame also has a transparent central artwork window.
