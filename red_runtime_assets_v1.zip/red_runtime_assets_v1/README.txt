BLAZING BATTLE - RED ASSET PACK v1

Character: Red
Purpose: runtime-ready source assets for implementation/testing.

Included:
- reference/red_master_reference.png
- idle/red_idle_orb_toss_12f.png           12-frame idle/toss loop source
- basic/red_basic_orb_throw_part01_f01-f07.png
- basic/red_basic_orb_throw_part02_f08-f14.png
                                                14-frame basic attack split across two HQ sheets
- recoil/red_recoil_8f.png                  8-frame recoil source
- props/red_capture_orb.png                 reusable standalone capture orb
- vfx/red_capture_orb_release_blue_14f.png  14-frame orb opening / blue release flash

Implementation notes:
- Preserve transparent alpha.
- Basic attack uses the standalone orb as the projectile; it does NOT open during the basic.
- Basic animation ends with Red embarrassed, hand on/behind head.
- Orb opening/release sequence is intended for monster summon attacks and is separate from the monster itself.
- Attack source was intentionally split into two sheets to provide larger gutters and preserve sprite detail.
- Do not downscale source sheets destructively. Slice into runtime frames from these HQ masters.
